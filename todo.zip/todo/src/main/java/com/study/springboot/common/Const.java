package com.study.springboot.common;

public class Const {
	
	public static final int CODE_JOIN_DUP_ID = -1; // 아이디 중복
	public static final int CODE_JOIN_NULL_ID = -2;// 아이디 없음
	public static final int CODE_JOIN_NULL_PW = -3;// 비번 없음
	
}
