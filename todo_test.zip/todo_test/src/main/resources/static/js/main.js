/**
 * 
 */
document.addEventListener("DOMContentLoaded", function() {
    var joinForm = document.getElementById("joinForm");
    var idInput = document.getElementById("id");
    var idCheckResult = document.getElementById("idCheckResult");
    
    // 아이디 입력 시 중복 검사 요청
    idInput.addEventListener("input", function() {
        var id = idInput.value;
        
        // 중복 검사를 위한 Ajax 요청
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "/user/checkIdDuplicate?id=" + id);
        
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    var response = xhr.responseText;
                    if (response === "duplicate") {
                        idCheckResult.textContent = "이미 사용 중인 아이디입니다.";
                        idCheckResult.style.color = "red";
                        joinForm.elements["id"].setCustomValidity("이미 사용 중인 아이디입니다.");
                    } else {
                        idCheckResult.textContent = "사용 가능한 아이디입니다.";
                        idCheckResult.style.color = "green";
                        joinForm.elements["id"].setCustomValidity("");
                    }
                } else {
                    console.error("An error occurred while checking ID duplicate.");
                }
            }
        };
        
        xhr.send();
    });
});
