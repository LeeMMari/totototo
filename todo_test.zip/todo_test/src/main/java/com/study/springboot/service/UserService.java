package com.study.springboot.service;

import java.util.List;

import com.study.springboot.dto.UserDTO;

public interface UserService {
	
	int setUser(String id, String pw);
	List getUser();
	// DAO의 updateUser() 호출
	int modifyUser(String name);
	
	// DTO에서 받아 삭제하는 메소드 작성
	int deleteUser(UserDTO dto);
	
	// DTO에서 받아 회원가입
	int joinUser(UserDTO userDTO);
	
	boolean isIdDuplicate(String id);

}
