package com.study.springboot.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.study.springboot.dto.UserDTO;

@Mapper
public interface UserDAO {
	
	int insertUser(String id, String pw);
	List<UserDTO> selectUser();
	int updateUser(String name);
	
	// UserDTO의 정보를 받아 삭제메소드 작성
	int deleteUser(UserDTO userDTO);
	
	int joinUser(UserDTO userDTO);
	int idCheck(String id);
}
