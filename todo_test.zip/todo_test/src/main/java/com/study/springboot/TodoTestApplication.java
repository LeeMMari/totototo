package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoTestApplication.class, args);
	}

}
