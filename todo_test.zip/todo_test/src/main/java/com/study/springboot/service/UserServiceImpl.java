package com.study.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.study.springboot.common.Const;
import com.study.springboot.dao.UserDAO;
import com.study.springboot.dto.UserDTO;

// 실질적으로 일하는 클래스
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserDAO userDAO;
	
	@Override
	public int setUser(String id, String pw) {
		
		int result = userDAO.insertUser(id, pw);
		
		return result;
	}
	
	@Override
	public List getUser() {
		List list = userDAO.selectUser();
		
		return list;
	}
	
	@Override
	// UserService 불러오기
	public int modifyUser(String name) {
		// modifyUser란 이름으로 DAO의 updateUser 불러오기
		// 결과를 result 에 담기
		int result = userDAO.updateUser(name);
		return result;
	}
	
	@Override
	public int deleteUser(UserDTO dto) {
		int result = userDAO.deleteUser(dto);
		return result;
	}
	
//	@Override
//	public int joinUser(UserDTO userDTO) {
//		int result = -1;
//		
//		// id가 이미 있는지 검사
//		int count_id = userDAO.idCheck(userDTO);
//		
//		if(count_id == 0) {
//			// id가 중복되지 않았다면
//			result = userDAO.joinUser(userDTO);
//			// result 에는 1(insert 성공), 0(insert 실패)
//		} else {
//			// id가 이미 존재한다면
//			result = Const.CODE_JOIN_DUP_ID;
//		}
//		return result;
//	}
	
	@Override
	public int joinUser(UserDTO userDTO) {
		// 중복 아이디 검사 수행x, 바로 회원가입 진행
		int result = userDAO.joinUser(userDTO);
		
		// result 에는 1(insert 성공), 0(insert 실패)
		
		return result;
	}
	
	@Override
	public boolean isIdDuplicate(String id) {
		int count = userDAO.idCheck(id);
		return count > 0;
	}
	

}
